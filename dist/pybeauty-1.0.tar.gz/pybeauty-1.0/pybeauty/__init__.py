from pybeauty.pybeauty import Beauty
